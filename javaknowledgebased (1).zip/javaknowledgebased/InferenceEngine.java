import java.util.ArrayList;
import java.util.List;

public class InferenceEngine {
    private KnowledgeBase knowledgeBase;
    private List<Rule> rules;

    public InferenceEngine(KnowledgeBase knowledgeBase) {
        this.knowledgeBase = knowledgeBase;
        this.rules = new ArrayList<>();
    }

    public void addRule(String condition, String action) {
        rules.add(new Rule(condition, action));
    }

    public void infer() {
        List<Fact> facts = knowledgeBase.getFacts();
        for (Rule rule : rules) {
            for (Fact fact : facts) {
                if (fact.getFact().equals(rule.getCondition())) {
                    knowledgeBase.addFact(rule.getAction(), "");
                }
            }
        }
    }
}
