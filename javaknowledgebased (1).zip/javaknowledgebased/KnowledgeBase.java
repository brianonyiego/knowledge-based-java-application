import java.util.ArrayList;
import java.util.List;

public class KnowledgeBase {
    private List<Fact> facts;
    private List<String> issues;
    private List<String> feedback;

    public KnowledgeBase() {
        facts = new ArrayList<>();
        issues = new ArrayList<>();
        feedback = new ArrayList<>();
    }

    public void addFact(String fact, String description) {
        facts.add(new Fact(fact, description));
    }

    public void addIssue(String issue) {
        issues.add(issue);
    }

    public void addFeedback(String feedback) {
        this.feedback.add(feedback);
    }

    public List<Fact> getFacts() {
        return facts;
    }

    public List<String> getIssues() {
        return issues;
    }

    public List<String> getFeedback() {
        return feedback;
    }
}
