import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class KBSApp {
    private JFrame frame;
    private JTextArea textArea;
    private JTextField inputField;
    private JTextField descriptionField;
    private JTextField issueField;
    private JTextField feedbackField;
    private JButton addFactButton;
    private JButton addIssueButton;
    private JButton addFeedbackButton;
    private JButton inferButton;
    private KnowledgeBase knowledgeBase;
    private InferenceEngine inferenceEngine;

    public KBSApp() {
        knowledgeBase = new KnowledgeBase();

        // Example rules
        List<Rule> rules = new ArrayList<>();
        rules.add(new Rule("sky is cloudy", "it might rain"));
        rules.add(new Rule("it might rain", "take an umbrella"));
        inferenceEngine = new InferenceEngine(rules);

        frame = new JFrame("Knowledge Based System");
        textArea = new JTextArea(20, 40);
        inputField = new JTextField(10);
        descriptionField = new JTextField(10);
        issueField = new JTextField(10);
        feedbackField = new JTextField(10);
        addFactButton = new JButton("Add Fact");
        addIssueButton = new JButton("Add Issue");
        addFeedbackButton = new JButton("Add Feedback");
        inferButton = new JButton("Infer");

        addFactButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String fact = inputField.getText();
                String description = descriptionField.getText();
                knowledgeBase.addFact(fact, description);
                updateTextArea();
                inputField.setText("");
                descriptionField.setText("");
            }
        });

        addIssueButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String issue = issueField.getText();
                knowledgeBase.addIssue(issue);
                updateTextArea();
                issueField.setText("");
            }
        });

        addFeedbackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String feedback = feedbackField.getText();
                knowledgeBase.addFeedback(feedback);
                updateTextArea();
                feedbackField.setText("");
            }
        });

        inferButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                inferenceEngine.infer(knowledgeBase);
                updateTextArea();
            }
        });

        JPanel panel = new JPanel();
        panel.add(new JLabel("Fact:"));
        panel.add(inputField);
        panel.add(new JLabel("Description:"));
        panel.add(descriptionField);
        panel.add(addFactButton);
        panel.add(new JLabel("Issue:"));
        panel.add(issueField);
        panel.add(addIssueButton);
        panel.add(new JLabel("Feedback:"));
        panel.add(feedbackField);
        panel.add(addFeedbackButton);
        panel.add(inferButton);

        frame.getContentPane().add(new JScrollPane(textArea), "Center");
        frame.getContentPane().add(panel, "South");
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    private void updateTextArea() {
        StringBuilder sb = new StringBuilder();
        sb.append("Knowledge Base:\n");
        for (String fact : knowledgeBase.getKnowledge().keySet()) {
            sb.append(fact).append(": ").append(knowledgeBase.getKnowledge().get(fact)).append("\n");
        }
        sb.append("\nIssues:\n");
        for (String issue : knowledgeBase.getIssues()) {
            sb.append(issue).append("\n");
        }
        sb.append("\nFeedback:\n");
        for (String feedback : knowledgeBase.getFeedback()) {
            sb.append(feedback).append("\n");
        }
        textArea.setText(sb.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new KBSApp();
            }
        });
    }
}
